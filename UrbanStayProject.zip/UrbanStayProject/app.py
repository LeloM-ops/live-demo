from flask import Flask, render_template, request, jsonify
from datetime import datetime

app = Flask(__name__)

# --- MOCK DATABASE ---
# In a real app, this would be an SQL database (Room, Guest, Booking tables)
rooms = {
    "101": {"type": "Single", "status": "Available", "rate": 850},
    "102": {"type": "Double", "status": "Available", "rate": 1200}
}

bookings = []

# --- ROUTES ---
@app.route('/')
def home():
    return render_template('index.html')

# DEMO 1: Create Booking & Prevent Double-Booking (FR4 & FR5)
@app.route('/api/book', methods=['POST'])
def create_booking():
    data = request.json
    room_num = data.get('room_number')
    check_in = data.get('check_in') # Format: YYYY-MM-DD
    check_out = data.get('check_out')
    guest_name = data.get('guest_name')

    # FR5 LOGIC: Validate overlapping bookings
    for booking in bookings:
        if booking['room_number'] == room_num:
            existing_in = booking['check_in']
            existing_out = booking['check_out']
            
            # Overlap logic: (New In < Existing Out) AND (New Out > Existing In)
            if (check_in < existing_out) and (check_out > existing_in):
                return jsonify({
                    "status": "error",
                    "message": f"Booking Conflict! Room {room_num} is already booked from {existing_in} to {existing_out}."
                }), 400

    # If no overlap, create booking (FR4)
    bookings.append({
        "room_number": room_num,
        "guest_name": guest_name,
        "check_in": check_in,
        "check_out": check_out
    })
    return jsonify({"status": "success", "message": "Booking successful!"})

# DEMO 2: Check-in & Update Status (FR7 & FR8)
@app.route('/api/checkin', methods=['POST'])
def check_in():
    data = request.json
    room_num = data.get('room_number')
    
    # FR7: Record timestamp
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # FR8: Update room status
    if room_num in rooms:
        rooms[room_num]['status'] = 'Occupied'
        return jsonify({
            "status": "success", 
            "message": f"Guest checked in at {current_time}. Room {room_num} is now Occupied."
        })
    return jsonify({"status": "error", "message": "Room not found"}), 404

if __name__ == '__main__':
    app.run(debug=True) 